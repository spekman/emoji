import { AuthScreenLayout } from '@/components/AuthScreenLayout';
import { theme } from '@/constants/theme';
import { useRouter } from 'expo-router';
import { useState } from 'react';
import { StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';

export default function LoginScreen() {
    const router = useRouter();
    const [identifier, setIdentifier] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleLogin = () => {
        if (!identifier.trim() || !password.trim()) {
            setError('Informe email ou nome de usuário e senha.');
            return;
        }

        setError('');
        router.push('/chatScreen');
    };

    return (
        <AuthScreenLayout>
            <Text selectable style={styles.title}>Entrar</Text>
            <Text selectable style={styles.description}>
                Use email ou nome de usuário e senha para acessar o seu pet.
            </Text>

            <TextInput
                style={styles.input}
                placeholder="Email ou nome do usuário"
                placeholderTextColor={theme.colors.textMuted}
                value={identifier}
                onChangeText={setIdentifier}
                autoCapitalize="none"
                keyboardType="email-address"
                textContentType="username"
            />
            <TextInput
                style={styles.input}
                placeholder="Senha"
                placeholderTextColor={theme.colors.textMuted}
                value={password}
                onChangeText={setPassword}
                secureTextEntry
                textContentType="password"
            />

            {error ? <Text selectable style={styles.error}>{error}</Text> : null}

            <TouchableOpacity onPress={handleLogin} activeOpacity={0.85}>
                <View
                    style={[
                        styles.button,
                        {
                            experimental_backgroundImage: theme.buttonGradient,
                            backgroundColor: theme.colors.accent,
                        },
                    ]}
                >
                    <Text selectable style={styles.buttonText}>Entrar</Text>
                </View>
            </TouchableOpacity>

            <View style={styles.footer}>
                <Text selectable style={styles.footerText}>Ainda não tem uma conta?</Text>
                <TouchableOpacity onPress={() => router.push('/register')}>
                    <Text selectable style={styles.linkText}>Criar conta</Text>
                </TouchableOpacity>
            </View>
        </AuthScreenLayout>
    );
}

const styles = StyleSheet.create({
    title: {
        fontSize: 28,
        fontWeight: '700',
        color: theme.colors.textPrimary,
        marginBottom: 8,
    },
    description: {
        color: theme.colors.textSecondary,
        fontSize: 14,
        lineHeight: 20,
        marginBottom: 24,
    },
    input: {
        height: 48,
        borderWidth: 1,
        borderColor: theme.colors.inputBorder,
        borderRadius: 14,
        borderCurve: 'continuous',
        paddingHorizontal: 16,
        marginBottom: 16,
        backgroundColor: theme.colors.inputBg,
        color: theme.colors.textPrimary,
    },
    button: {
        height: 48,
        borderRadius: 14,
        borderCurve: 'continuous',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 8,
        boxShadow: '0 4px 16px rgba(37, 99, 235, 0.45)',
    },
    buttonText: {
        color: theme.colors.textPrimary,
        fontWeight: '700',
        fontSize: 16,
    },
    footer: {
        marginTop: 20,
        flexDirection: 'row',
        justifyContent: 'center',
        gap: 8,
        flexWrap: 'wrap',
    },
    footerText: {
        color: theme.colors.textSecondary,
    },
    linkText: {
        color: theme.colors.textPrimary,
        fontWeight: '700',
    },
    error: {
        color: theme.colors.error,
        marginBottom: 12,
        fontSize: 13,
    },
});
